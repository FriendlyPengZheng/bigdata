﻿for(var i = 0; i < 20; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

if (true) {

	SetPanelVisibility('u9','hidden','none',500);

}

});

u13.style.cursor = 'pointer';
$axure.eventManager.click('u13', function(e) {

if (true) {

	var obj1 = document.getElementById("u13");
    obj1.disabled = false;

}
});

u12.style.cursor = 'pointer';
$axure.eventManager.click('u12', function(e) {

if (true) {

	SetPanelState('u9', 'pd1u9','none','',500,'none','',500);

}
});
gv_vAlignTable['u4'] = 'top';gv_vAlignTable['u8'] = 'top';
u17.style.cursor = 'pointer';
$axure.eventManager.click('u17', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('自定义查询页面.html');

}
});
gv_vAlignTable['u1'] = 'center';
u14.style.cursor = 'pointer';
$axure.eventManager.click('u14', function(e) {

if (true) {

	var obj1 = document.getElementById("u15");
    obj1.disabled = true;

}
});

u15.style.cursor = 'pointer';
$axure.eventManager.click('u15', function(e) {

if (true) {

	var obj1 = document.getElementById("u15");
    obj1.disabled = false;

}
});

u16.style.cursor = 'pointer';
$axure.eventManager.click('u16', function(e) {

if (true) {

	var obj1 = document.getElementById("u13");
    obj1.disabled = true;

}
});
gv_vAlignTable['u6'] = 'top';gv_vAlignTable['u2'] = 'top';gv_vAlignTable['u11'] = 'center';gv_vAlignTable['u18'] = 'top';
u7.style.cursor = 'pointer';
$axure.eventManager.click('u7', function(e) {

if (((GetCheckState('u3')) == (false)) && ((GetCheckState('u5')) == (false))) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('未选中任何项时报错.html');

}
else
if (((GetCheckState('u3')) == (true)) || ((GetCheckState('u5')) == (true))) {

	SetPanelState('u9', 'pd0u9','none','',500,'swing','left',500);

}
});
