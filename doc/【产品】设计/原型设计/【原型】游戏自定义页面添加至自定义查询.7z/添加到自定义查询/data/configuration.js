﻿var configuration = 

(function() {
    var _ = function() { var r={},a=arguments; for(var i=0; i<a.length; i+=2) r[a[i]]=a[i+1]; return r; }
    var _creator = function() { return _(b,c,d,e,f,e);}; 
var b="showPageNotes",c=true,d="showPageNoteNames",e=false,f="loadFeedbackPlugin";
return _creator();
})()