﻿var sitemap = 

(function() {
    var _ = function() { var r={},a=arguments; for(var i=0; i<a.length; i+=2) r[a[i]]=a[i+1]; return r; }
    var _creator = function() { return _(b,[_(c,d,e,f,g,h,i,[_(c,j,e,f,g,k),_(c,l,e,f,g,m),_(c,n,e,f,g,o),_(c,p,e,f,g,q)])]);}; 
var b="rootNodes",c="pageName",d="主页",e="type",f="Wireframe",g="url",h="主页.html",i="children",j="未选中任何项时报错",k="未选中任何项时报错.html",l="自定义查询页面",m="自定义查询页面.html",n="数据项超出时报错",o="数据项超出时报错.html",p="差集数据项超出报错",q="差集数据项超出报错.html";
return _creator();
})();
